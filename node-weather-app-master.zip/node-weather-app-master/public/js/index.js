console.log('TEST: This is working');
const body = document.querySelector('body');
console.log(body)